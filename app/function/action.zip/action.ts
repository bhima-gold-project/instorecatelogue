import { PostData } from '@/app/Api/post/post_api_service';
import { BRANCH_MASTER_PUSH, BRANCH_ORDER_PUSH, CREATE_ORDER, CUSTOMER_NEW_REGISTRATION_SERVER, DELETE_CART_ITEM, ERP_DATA_PUSH_URL, GENDER_LIST, GET_ALL_BRANCH_LIST, GET_BANNER_LIST, GET_CART_BY_CART_ID, GET_CART_BY_USERID, GET_CATEGORY_FROM_SERVER, GET_CENTRAL_DATA_BY_BARCODE, GET_CUSTOMER_DETAILS_FROM_SERVER, GET_RATE_BY_BARCODE, ORDER_BY_BRANCH_URL, ORDER_DETAILS_BY_ORDER_ID, RATE_UPADTE, RESET_INV, STORE_REGISTARTION, VERIFY_OTP_URL, CHECK_BRANCH_RATE, BRANCH_WISE_CART } from "../Api/api_list"
import { getData } from "../Api/get/get_api_service"
import Cookies from "js-cookie"
import { user } from '@nextui-org/react';




const cartid: any = Cookies.get("_si_cart_id")
const test: any = "cart_1739351790746SEH985"
export let homeBranchValue = Cookies.get("homebranch")
export let loginid = Cookies.get("_si_login_id")

// const getCookieValue = (name: string) => {
//     if (typeof window !== "undefined") {
//       const value = `; ${document.cookie}`
//       const parts = value.split(`; ${name}=`)
//       if (parts.length === 2) return parts.pop()?.split(";").shift()
//     }
//     return null 
//   }


// const userid=getCookieValue("_si_login_id")


export const getCartData = async () => {
    const response = await getData(`${GET_CART_BY_CART_ID}${test}`)
    if (response) {
        return response
    }
    else
        return []
}


export const getOrderList = async () => {

    const res = await getData(`${ORDER_BY_BRANCH_URL}/${homeBranchValue}`)

    if (res) {
        return res
    }
    else {
        return []
    }
}


export const getOrdersDetails = async (orderId: any) => {
    const res = await getData(`${ORDER_DETAILS_BY_ORDER_ID}/${orderId}`)
    if (res) {
        return res
    }
    else {
        return []
    }
}


export const customerLoginApi = async (mobilenumber: any) => {
    const res = await getData(`${GET_CUSTOMER_DETAILS_FROM_SERVER}${mobilenumber}`)
    if (res) {
        return res
    }
    else {
        return []
    }

}

export const customerRegistrationApi = async (data: any) => {
    const res = await PostData(`${CUSTOMER_NEW_REGISTRATION_SERVER}`, data)
    if (res) {
        return res
    }
    else {
        return []
    }

}

export const deleteLineItem = async (id: any, uid: any) => {

    const data =
    {
        "line_item_id": id
    }
    const res = await PostData(`${DELETE_CART_ITEM}`, data)
    
    if (res) {
        return true
    }
    else {
        return false
    }
}


export const CreateOrder = async (data: any) => {
    const res = await PostData(`${CREATE_ORDER}`, data)
    if (res) {
        return res
    }
    else {

        return []

    }

}


export const GetCartByUserId = async (userid: any) => {
    const loginId = Cookies.get("_si_login_id");
    const cartid = Cookies.get("_si_cart_id");

    // const res = await getData(`${GET_CART_BY_USERID}${userid}`)
    const res = await getData(`${GET_CART_BY_CART_ID}${cartid}`)
    if (res) {
        //     Cookies.set("_cart_length", res.length);
        return res
    }
    else {
        return []
    }
}



export const CreateCentralOrder = async (data: any) => {
    const res = await PostData(`${ERP_DATA_PUSH_URL}`, data)
    if (res) {
        return res
    }
    else {
        return []
    }
}



export const getBranches = async () => {
    const res = await getData(`${GET_ALL_BRANCH_LIST}`)
    if (res) {
        if (Array.isArray(res)) {
            return res.filter((item: any) => item.branch_code && item.branch_code.toUpperCase() !== "ALL")
        }
        return res
    }
    else {
        return []
    }
}


export const getAllCategoryApi = async () => {

    const res = await getData(`${GET_CATEGORY_FROM_SERVER}`)
    if (res) {
        if (Array.isArray(res)) {
            return res.map((item: any) => {
                const name = item.CategoryName || item.categoryName;
                return {
                    ...item,
                    categoryName: name,
                    CategoryName: name
                };
            });
        }
        return res
    }
    else {
        return []
    }
}


export const VerifyBranchLogin = async (email: any, otp: any) => {
    const data = {
        UserName: email,
        Password: otp,
    }
    const res = await PostData(`${VERIFY_OTP_URL}`, data)
    if (res) {
        return res
    }
    else {
        return []
    }

}

export const Logout = () => {
    const status = confirm(`Are you sure you want to logout ?`)
    if (status) {
        Cookies.remove("homebranch");
        Cookies.remove("_cart_length");
        window.location.reload()

    }
};



export const getBanner = async () => {
    const res = await getData(`${GET_BANNER_LIST}`)
    if (res) {
        return res
    }
    else {
        return []
    }

}

export const UpdateRate = async (data: any) => {
    const res = await PostData(`${RATE_UPADTE}`, data)

    if (res) {
        return res
    }
    else {
        return []
    }
}

export const getCentralDbdata = async (barcode: any) => {

    const res = await getData(`${GET_CENTRAL_DATA_BY_BARCODE}${barcode}`)

    if (res) {

        return res
    }
    else {
        return []
    }

}


export const getCentralDbdataforcart = async (barcode: any) => {
    let res = await getData(`${GET_CENTRAL_DATA_BY_BARCODE}${barcode}`)
    if (Array.isArray(res)) {
        res = res.length > 0 ? res[0] : null;
    }
    if (res) {
        return res
    }
    else {
        return []
    }

}

export const NewStoreRegistration = async (data: any) => {


    const res = await PostData(`${STORE_REGISTARTION}`, data)
    if (res) {

        return res
    }
    else {
        return []
    }

}



export const getGender = async () => {
    const res = await getData(`${GENDER_LIST}`)
    if (res) {
        return res
    }
    else {
        return []
    }

}

export const fetcher = async (url: string) => {
    const response = await fetch(url);
    if (!response.ok) throw new Error("Failed to fetch");
    return response.json();
};



export const GetRateByBarcode = async (barcode: any) => {
    const res = await getData(`${GET_RATE_BY_BARCODE}${barcode}`)
    if (res) {
        return res
    }
    else {
        return []
    }
}


export const barnchOrderPush = async (barcode: any) => {
    const res = await getData(`${BRANCH_ORDER_PUSH}${barcode}`)
    if (res) {
        return res
    }
    else {
        return []
    }
}

export const barnchMasterPush = async (barcode: any) => {
    const res = await getData(`${BRANCH_MASTER_PUSH}${barcode}`)
    if (res) {
        return res
    }
    else {
        return []
    }
}


export const invUpdation = async (data: any) => {


    const res = await PostData(`${RESET_INV}`, data)
    if (res) {

        return res
    }
    else {
        return []
    }

}

export const checkBranchProductsRate = async (data: any) => {
    const res = await PostData(`${CHECK_BRANCH_RATE}`, data)
    if (res) {
        return res
    }
    else {
        return []
    }
}

export const branchWiseCart = async (data: any) => {
    const res = await PostData(`${BRANCH_WISE_CART}`, data)
    if (res) {
        return res
    }
    else {
        return []
    }
}