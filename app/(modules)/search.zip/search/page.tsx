"use client";
import { bhima_boy_Image, GLOBAL_SEARCH_API, GET_ITEM_CODES } from "@/app/Api/api_list";
import { Font_20px } from "@/app/components/labels/page";
import { gender as genderData, gscodes, prices, purities, stocks, weightlist } from "@/app/Data/filterdata";
import { getBranches, getGender, getAllCategoryApi, checkBranchProductsRate, getCentralDbdata } from "@/app/function/action";
import { formatIndianNumber } from "@/app/function/fx";
import { RotateCcw } from "lucide-react";
import { useSearchParams, useRouter } from "next/navigation";
import React, { useState, useEffect, Suspense } from "react";
import useSWR from "swr";
import Cookies from "js-cookie";
import Breadcrumb from "@/app/components/page";
import ProductThumbnail from "../categories/product-thumbnail/page";
import SearchableSelect from "@/app/components/SearchableSelect";

const fetcher = async (url: string) => {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error("Failed to fetch");
  }
  return response.json();
};

function SearchPageContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const q = searchParams.get("q") || "";

  const [category, setcategory] = useState<any>([]);
  const [categoryvalue, setCategoryValue] = useState("All");

  const [collectionDetail, setCollectionDetailState] = useState<any[]>([]);
  const [totalproduct, setTotalproducts] = useState(0);

  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(25);

  const [branch, setBranch] = useState([]);
  const [selectedgender, setselectedgender] = useState(searchParams.get("gender") || "All");
  const [choosenBranch, setChoosenBranch] = useState(searchParams.get("branch") || "All");
  const [selectedstock, setselectedstock] = useState(searchParams.get("stock") || "All");
  const [selectedpurity, seselectedpurity] = useState(searchParams.get("purity") || "All");
  const [selectedgscode, seselectedgscode] = useState(searchParams.get("gscode") || "All");
  const [selecteditemcode, setSelecteditemcode] = useState(searchParams.get("itemcode") || "All");
  const [selectedprice, setselectedprice] = useState(searchParams.get("price") || "All");

  // Custom range filters
  const [minWeight, setMinWeight] = useState(searchParams.get("minWeight") || "");
  const [maxWeight, setMaxWeight] = useState(searchParams.get("maxWeight") || "");
  const [minCarat, setMinCarat] = useState(searchParams.get("minCarat") || "");
  const [maxCarat, setMaxCarat] = useState(searchParams.get("maxCarat") || "");

  const [totalpages, setTotalPages] = useState(0);
  const [currentpage, setCurrentPage] = useState(1);
  const [reset, setReset] = useState(false);

  const [genderlist, setGenderlist] = useState<any>([]);
  const [itemcodeslist, setItemcodeslist] = useState<any[]>([]);

  // Build query string dynamically for ranges
  const buildQuery = () => {
    const loginbranch = Cookies.get("homebranch") ;
    let query = `${GLOBAL_SEARCH_API}?q=${encodeURIComponent(q)}&page=${page}&limit=${limit}&branchCode=${choosenBranch}&stockStatus=${selectedstock}&purity=${selectedpurity}&gswise=${selectedgscode}&itemCode=${selecteditemcode}&priceRange=${selectedprice}&gender=${selectedgender}&loginbranch=${loginbranch}`;
    if (minWeight) query += `&minWeight=${minWeight}`;
    if (maxWeight) query += `&maxWeight=${maxWeight}`;
    const effectiveMinCarat = (!minCarat || minCarat.trim() === "") ? "0.001" : minCarat;
    query += `&minCarat=${effectiveMinCarat}`;
    if (maxCarat) query += `&maxCarat=${maxCarat}`;
    return query;
  };

  const base = buildQuery();

  const { data, error, isLoading } = useSWR(base, fetcher);

  useEffect(() => {
    if (
      choosenBranch !== "All" ||
      selectedstock !== "All" ||
      selectedpurity !== "All" ||
      selectedprice !== "All" ||
      selectedgscode !== "All" ||
      selecteditemcode !== "All" ||
      selectedgender !== "All" ||
      minWeight !== "" ||
      maxWeight !== "" ||
      minCarat !== "" ||
      maxCarat !== ""
    ) {
      setPage(1);
    }
  }, [
    choosenBranch,
    selectedstock,
    selectedpurity,
    selectedprice,
    selectedgscode,
    selecteditemcode,
    selectedgender,
    minWeight,
    maxWeight,
    minCarat,
    maxCarat,
    reset,
  ]);

  useEffect(() => {
    if (data?.success) {
      if (page === 1) {
        setCollectionDetailState(data.data || []);
        fetchRatesForProducts(data.data || []);
      } else {
        setCollectionDetailState((prevProducts = []) => {
          const newProducts = Array.isArray(data.data) ? data.data : [];
          const combinedProducts = [...prevProducts, ...newProducts];

          const uniqueProducts = Array.from(
            new Map(combinedProducts.map((product) => [product.id, product]))
          ).map(([_, product]) => product);
          return uniqueProducts;
        });
        fetchRatesForProducts(Array.isArray(data.data) ? data.data : []);
      }

      setTotalproducts(data.metadata?.totalItems || 0);
      setTotalPages(data.metadata?.totalPages || 0);
      setCurrentPage(data.metadata?.currentPage || 1);
      setReset(false);
    }
  }, [data, page, reset]);

  const handleLoadMore = () => {
    setPage((prev) => prev + 1);
  };

  useEffect(() => {
    const getAllBranch = async () => {
      try {
        const branches = await getBranches();
        setBranch(branches);
      } catch (error) {
        console.error("Error fetching branches:", error);
      }
    };
    getAllBranch();
  }, []);

  const handleSingleProductRefresh = async (BarcodeNo: string, productbranch: any) => {
    try {
      const branchcode = Cookies.get("homebranch") || "BH"
      const res = await checkBranchProductsRate({ branchcode, BarcodeNo, ProductBranch: productbranch })
      
      let newImageUrl = null;
      try {
        const centralRes = await getCentralDbdata(BarcodeNo);
        if (centralRes && centralRes.ImageUrl && Array.isArray(centralRes.ImageUrl) && centralRes.ImageUrl.length > 0) {
           const imageArray = centralRes.ImageUrl;
           const mainImage = imageArray.find((img: string) => img.toLowerCase().includes('main'));
           if (mainImage) {
             newImageUrl = mainImage;
           } else {
             newImageUrl = imageArray[0];
          }
        }
      } catch (imgError) {
         console.error(`Error fetching central image for ${BarcodeNo}:`, imgError);
      }
      
      if (res && res.data) {
        setCollectionDetailState((prev) => {
          const updated = prev.map((item) => {
            if (String(item.barcode) === String(BarcodeNo)) {
              const updatedItem = { ...item, price: res.data[0].FinalAmount };
              if (newImageUrl) {
                updatedItem.customThumbnail = newImageUrl;
              }
              return updatedItem;
            }
            return item
          })
          return updated
        })
      }
    } catch (error) {
      console.log(error)
    }
  }

  const fetchRatesForProducts = async (products: any[]) => {
    const branchcode = Cookies.get("homebranch") || "BH"
    if (!products || products.length === 0) return

    try {
      const ratePromises = products.map(async (product: any) => {
        try {
          const res = await checkBranchProductsRate({
            branchcode,
            BarcodeNo: product.barcode,
            ProductBranch: product.branch_code,
          })
          
          let price = 'xxxx';
          if (res && res.data && res.data.length > 0 && res.data[0].FinalAmount) {
            price = res.data[0].FinalAmount;
          }
          
          let newImageUrl = product.thumbnail;
          try {
            const centralRes = await getCentralDbdata(product.barcode);
            if (centralRes && centralRes.ImageUrl && Array.isArray(centralRes.ImageUrl) && centralRes.ImageUrl.length > 0) {
               const imageArray = centralRes.ImageUrl;
               const mainImage = imageArray.find((img: string) => img.toLowerCase().includes('main'));
               if (mainImage) {
                 newImageUrl = mainImage;
               } else {
                 newImageUrl = imageArray[0];
               }
            }
          } catch (imgError) {
             console.error(`Error fetching central image for ${product.barcode}:`, imgError);
          }
          
          return { barcode: product.barcode, price, newImageUrl }
        } catch (error) {
          console.error(`Error fetching rate for ${product.barcode}:`, error)
        }
        return null
      })

      const results = await Promise.all(ratePromises)
      const validUpdates = results.filter((r) => r !== null)

      if (validUpdates.length > 0) {
        setCollectionDetailState((prev) => {
          const updated = prev?.map((item) => {
            const update = validUpdates.find(
              (u: any) => String(u.barcode) === String(item.barcode)
            )
            if (update) {
              return { ...item, price: update.price, customThumbnail: update.newImageUrl }
            }
            return item
          })
          return updated
        })
      }
    } catch (error) {
      console.error("Error in fetchRatesForProducts", error)
    }
  }

  const getData = async () => {
    try {
      const data = await getAllCategoryApi();
      setcategory(data);
      const gender = await getGender();
      setGenderlist(gender);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    getData();
  }, []);

  useEffect(() => {
    const fetchItemCodes = async () => {
      try {
        const categoryName = decodeURIComponent(categoryvalue);
        const categoryParam = categoryName !== "All" ? `?category=${encodeURIComponent(categoryName)}` : "";
        const res = await fetch(`${GET_ITEM_CODES}${categoryParam}`);
        const itemCodesData = await res.json();
        if (itemCodesData.success) {
          setItemcodeslist(itemCodesData.data);
        }
      } catch (error) {
        console.error("Error fetching item codes:", error);
      }
    };
    fetchItemCodes();
  }, [categoryvalue]);

  useEffect(() => {
    localStorage.setItem("plp_list", JSON.stringify(collectionDetail));
  }, [collectionDetail]);

  const handleCategory = (selectedCategory: string) => {
    setCategoryValue(selectedCategory);
    if (selectedCategory !== "All" && selectedCategory !== "") {
      const query = new URLSearchParams();
      if (choosenBranch !== "All") query.set("branch", choosenBranch);
      if (selectedstock !== "All") query.set("stock", selectedstock);
      if (selectedpurity !== "All") query.set("purity", selectedpurity);
      if (selectedgscode !== "All") query.set("gscode", selectedgscode);
      if (selecteditemcode !== "All") query.set("itemcode", selecteditemcode);
      if (selectedprice !== "All") query.set("price", selectedprice);
      if (selectedgender !== "All") query.set("gender", selectedgender);
      if (minWeight) query.set("minWeight", minWeight);
      if (maxWeight) query.set("maxWeight", maxWeight);
      if (minCarat) query.set("minCarat", minCarat);
      if (maxCarat) query.set("maxCarat", maxCarat);
      router.push(`/categories/${selectedCategory}?${query.toString()}`);
    }
  };

  const Reset = () => {
    setCategoryValue("All");
    setChoosenBranch("All");
    setselectedstock("All");
    seselectedpurity("All");
    seselectedgscode("All");
    setSelecteditemcode("All");
    setselectedprice("All");
    setselectedgender("All");
    setMinWeight("");
    setMaxWeight("");
    setMinCarat("");
    setMaxCarat("");
  };

  const branchOptions = [
    { value: "All", label: "All" },
    ...(branch?.map((item: any) => ({
      value: item.branch_code,
      label: item.branch_code,
    })) || []),
  ];

  const categoryOptions = [
    { value: "All", label: "All" },
    ...(category?.map((item: any) => {
      const name = item.CategoryName || item.categoryName;
      return { value: name, label: name };
    }) || [])
  ];

  const gscodeOptions = gscodes?.map((item: any) => ({
    value: item.value || item.values || "",
    label: item.label || "",
  })) || [];

  const itemcodeOptions = [
    { value: "All", label: "All" },
    ...(itemcodeslist?.map((item: any) => ({
      value: item.Item_code,
      label: item.Item_code,
    })) || []),
  ];

  const stockOptions = stocks || [];
  const purityOptions = purities || [];
  const priceOptions = prices || [];

  const genderOptions = [
    { value: "All", label: "All" },
    ...(genderlist?.filter((item: any) => item.gender !== 'All').map((item: any) => ({
      value: item.gender,
      label: item.gender,
    })) || []),
  ];

  const weightOptions = weightlist || [];

  return (
    <div className="bg-cream min-h-screen pb-16 selection:bg-amber-100/30">

      {/* Breadcrumb section */}
      <div className="pt-[18px] px-4 md:px-9">
        <div className="w-28 mt-2">
          <Breadcrumb />
        </div>
      </div>

      {/* Page Head section */}
      <div className="pt-[22px] px-4 md:px-9 pb-1 flex flex-row items-end justify-between">
        <h1 className="font-cormorant font-bold text-[34px] text-ink relative pb-2 after:content-[''] after:absolute after:left-0 after:bottom-0 after:w-[42px] after:h-[2px] after:bg-gold">
          Search Results for: "{q}"
        </h1>
        <div className="text-[13px] text-ink-soft">
          Total Products: <b className="text-ink font-semibold">{formatIndianNumber(totalproduct || 0)}</b>
        </div>
      </div>

      {/* Filters section */}
      <div className="mx-4 md:mx-9 mt-[22px] bg-white border border-[rgba(42,36,32,0.1)] rounded-[14px] p-[18px] md:px-[22px] flex flex-wrap gap-y-[18px] gap-x-[22px] items-end shadow-[0_14px_30px_-22px_rgba(42,36,32,0.25)]">
        <SearchableSelect
          label="Branch"
          options={branchOptions}
          value={choosenBranch}
          onChange={setChoosenBranch}
        />
       
       
        <SearchableSelect
          label="Category"
          options={categoryOptions}
          value={categoryvalue}
          onChange={handleCategory}
        />
        <SearchableSelect
          label="Product Code"
          options={itemcodeOptions}
          value={selecteditemcode}
          onChange={setSelecteditemcode}
        />
        {/* <SearchableSelect
          label="GS Code"
          options={gscodeOptions}
          value={selectedgscode}
          onChange={seselectedgscode}
        /> */}
        <SearchableSelect
          label="Stock"
          options={stockOptions}
          value={selectedstock}
          onChange={setselectedstock}
        />
        <SearchableSelect
          label="Purity"
          options={purityOptions}
          value={selectedpurity}
          onChange={seselectedpurity}
        />
       
        <SearchableSelect
          label="Price"
          options={priceOptions}
          value={selectedprice}
          onChange={setselectedprice}
        />
        <SearchableSelect
          label="Gender"
          options={genderOptions}
          value={selectedgender}
          onChange={setselectedgender}
        />

        <div className="flex flex-col gap-1.5">
          <label className="text-[11px] tracking-[0.06em] uppercase text-ink-soft font-medium">Weight (g)</label>
          <div className="flex items-center gap-[6px]">
            <input type="number" min="0" placeholder="Min" className="font-jost border border-[rgba(42,36,32,0.1)] bg-cream rounded-lg px-3 py-2 text-[13px] text-ink outline-none w-[70px] focus:border-gold focus:shadow-[0_0_0_3px_rgba(184,146,79,0.12)] transition-all duration-200" value={minWeight} onChange={(e) => setMinWeight(e.target.value)} />
            <span className="text-ink-soft text-[12px]">–</span>
            <input type="number" min="0" placeholder="Max" className="font-jost border border-[rgba(42,36,32,0.1)] bg-cream rounded-lg px-3 py-2 text-[13px] text-ink outline-none w-[70px] focus:border-gold focus:shadow-[0_0_0_3px_rgba(184,146,79,0.12)] transition-all duration-200" value={maxWeight} onChange={(e) => setMaxWeight(e.target.value)} />
          </div>
        </div>

        <div className="flex flex-col gap-1.5">
          <label className="text-[11px] tracking-[0.06em] uppercase text-ink-soft font-medium">Carat</label>
          <div className="flex items-center gap-[6px]">
            <input type="number" min="0" placeholder="Min" className="font-jost border border-[rgba(42,36,32,0.1)] bg-cream rounded-lg px-3 py-2 text-[13px] text-ink outline-none w-[70px] focus:border-gold focus:shadow-[0_0_0_3px_rgba(184,146,79,0.12)] transition-all duration-200" value={minCarat} onChange={(e) => setMinCarat(e.target.value)} />
            <span className="text-ink-soft text-[12px]">–</span>
            <input type="number" min="0" placeholder="Max" className="font-jost border border-[rgba(42,36,32,0.1)] bg-cream rounded-lg px-3 py-2 text-[13px] text-ink outline-none w-[70px] focus:border-gold focus:shadow-[0_0_0_3px_rgba(184,146,79,0.12)] transition-all duration-200" value={maxCarat} onChange={(e) => setMaxCarat(e.target.value)} />
          </div>
        </div>

        <button onClick={Reset} className="flex items-center gap-[6px] text-gold-deep text-[13px] font-medium bg-transparent border-none cursor-pointer py-2 px-1 hover:opacity-70 transition-opacity duration-200 group">
          <RotateCcw className="w-[14px] h-[14px] group-hover:-rotate-90 transition-transform duration-400" />
          Clear Filters
        </button>
      </div>

      {/* Product Grid Section */}
      <div className="pt-[30px] px-4 md:px-9 pb-[70px]">
        {data && data.data && data.data.length === 0 && (
          <div className="w-full flex justify-center mt-10">
            <div className="font-semibold text-lg text-ink-soft">No Products Found for "{q}"!</div>
          </div>
        )}

        <div className="grid grid-cols-2 md:grid-cols-5 gap-[22px]">
          {collectionDetail && collectionDetail.length > 0 &&
            collectionDetail.map((productObj: any, index: number) => {
              return (
                <ProductThumbnail
                  key={index}
                  imageUrl={productObj?.customThumbnail ? productObj.customThumbnail : (productObj?.thumbnail || bhima_boy_Image)}
                  label={productObj.title || ""}
                  barcode={productObj.barcode}
                  amount={productObj.price || ""}
                  inventoryQuantity={productObj.inventory_quantity}
                  onRefresh={handleSingleProductRefresh}
                  productbranch={productObj?.branch_code}
                />
              );
            })}
        </div>

        {currentpage < totalpages && (
          <div className="flex justify-center mt-12 mb-20 items-center">
            <button
              className="bg-emerald text-white tracking-widest text-xs uppercase px-8 py-3 rounded-full hover:bg-gold-deep transition-colors duration-300 shadow-md"
              onClick={handleLoadMore}
            >
              Load More...
            </button>
          </div>
        )}
      </div>

    </div>
  );
}

export default function SearchPage() {
  return (
    <Suspense fallback={<div className="container mx-auto pt-20 px-5">Loading search...</div>}>
      <SearchPageContent />
    </Suspense>
  );
}
